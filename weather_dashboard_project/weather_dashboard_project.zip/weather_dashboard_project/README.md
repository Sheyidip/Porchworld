Hi, my name is ABOSEDE OGUNDIPE, Iam an Alx cohort 22 software engineering student specialized in frontend end and i created
A simple and elegant weather dashboard that displays real-time weather information for any city worldwide. Built with HTML, CSS, and JavaScript using the OpenWeatherMap API.
This is a solo project.

frontend : Abosede Ogundipe
Backend : uses a weather api to get real time data
email: sheyidip@gmail.com
Github name @sheyidip

Features

Real-time Weather Data: Get current weather information for any city
Detailed Weather Information:

Current temperature
"Feels like" temperature
Humidity levels
Wind speed
Weather description with icons


Responsive Design: Works seamlessly on desktop and mobile devices
Error Handling: Clear error messages for invalid city names or API issues
Clean User Interface: Modern and intuitive design
Instant Search: Get weather data by pressing Enter or clicking the search button

Technologies Used

HTML5
CSS3
JavaScript (ES6+)
OpenWeatherMap API
Font Awesome Icons
